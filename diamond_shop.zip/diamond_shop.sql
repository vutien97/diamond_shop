-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2021 at 03:47 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `diamond_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
CREATE TABLE `bill` (
  `id` bigint(20) NOT NULL,
  `email` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `total` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `note` text COLLATE utf8_vietnamese_ci,
  `billDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`id`, `email`, `phone`, `display_name`, `address`, `total`, `quantity`, `note`, `billDate`, `status`) VALUES
(3, 'vutien97dhtb@gmail.com', '0943828536', 'Tiáº¿n VÅ©', 'HÃ  Ná»?i', 420000, 3, 'None', '2020-12-15 22:47:46', 1),
(4, 'vutien97dhtb@gmail.com', '0943828536', 'Tiáº¿n VÅ©', 'HÃ  Ná»?i', 220000, 2, '', '2020-12-15 22:48:09', 1),
(5, 'vxt.97dhtb01@gmail.com', '0943828536', 'VÅ© Tiáº¿n', 'HÃ  Ná»?i', 1000000, 5, '', '2020-12-19 09:40:48', 1),
(6, 'vxt.97dhtb01@gmail.com', '0943828536', 'VÅ© Tiáº¿n', 'HÃ  Ná»?i', 220000, 2, '', '2020-12-19 22:04:23', 1),
(7, 'vutien97dhtb@gmail.com', '', 'Tiáº¿n VÅ©', '', 620000, 4, '', '2020-12-16 21:55:09', 1),
(8, 'vutien97dhtb@gmail.com', '0943828536', 'Tiáº¿n VÅ©', 'HÃ  Ná»?i', 420000, 3, '', '2020-12-08 12:08:11', 0),
(9, 'vutien97dhtb@gmail.com', '0943828536', 'Tiáº¿n VÅ©', 'HÃ  Ná»?i', 420000, 3, '', '2020-12-08 12:09:43', 0),
(10, 'vxt.97dhtb01@gmail.com', '0943828536', 'VÅ© Tiáº¿n', 'HÃ  Ná»?i', 20000, 1, '', '2020-12-08 12:13:30', 0),
(11, 'vutien97dhtb@gmail.com', '0943828536', 'Tiáº¿n VÅ©', 'HÃ  Ná»?i', 220000, 2, '', '2020-12-08 12:22:39', 0),
(12, 'vutien97dhtb@gmail.com', '0943828536', 'Tiáº¿n VÅ©', 'HÃ  Ná»?i', 220000, 2, '', '2020-12-08 12:28:14', 0),
(13, 'vutien97dhtb@gmail.com', '0943828536', 'Tiáº¿n VÅ©', 'HÃ  Ná»?i', 20000, 1, '', '2020-12-08 12:35:43', 0),
(14, 'vutien97dhtb@gmail.com', '0943828536', 'Tiáº¿n VÅ©', 'HÃ  Ná»?i', 400000, 2, '', '2020-12-08 12:36:39', 0),
(15, 'vutien97dhtb@gmail.com', '0943828536', 'Tiáº¿n VÅ©', 'HÃ  Ná»?i', 460000, 5, '', '2020-12-08 12:37:38', 0),
(16, 'b@gmail.com', '0943828536', 'Vũ Xuân Tiến', 'Thái Bình', 220000, 2, 'Giao hàng trong tuần', '2020-12-11 14:27:13', 0),
(17, 'b@gmail.com', '0943828536', 'Vũ Xuân Tiến', 'Thái Bình', 460000, 5, 'Giao vao cuối tuần', '2020-12-12 22:23:39', 0),
(18, 'b@gmail.com', '0943828536', 'Vũ Xuân Tiến', 'Thái Bình', 800000, 4, 'Giao vào buổi tối', '2020-12-12 23:57:56', 0),
(19, 'vutien97dhtb@gmail.com', '0943828536', 'Tiến Vũ', 'Hà Nội', 595000, 3, 'Giao vào buổi tối', '2020-12-15 16:59:08', 0),
(21, 'vutien97dhtb@gmail.com', '0943828536', 'null', 'Thái Bình', 265000, 1, 'Không', '2020-12-15 17:37:00', 0),
(22, 'vutien97dhtb@gmail.com', '0943828536', 'null', 'Thái Bình', 330000, 2, 'Không', '2020-12-15 17:38:45', 0),
(23, 'vutien97dhtb@gmail.com', '0943828536', 'null', 'Thái Bình', 480000, 2, '', '2020-12-16 21:18:22', 1),
(24, 'vutien97dhtb@gmail.com', '0943828536', 'Tiến Vũ', 'Thái Bình', 175000, 1, 'Không', '2020-12-15 22:48:23', 1),
(25, 'vutien97dhtb@gmail.com', '0943828536', 'Tiến Vũ', 'Thái Bình', 155000, 1, '', '2020-12-15 22:46:02', 1),
(26, 'vutien97dhtb@gmail.com', '0943828536', 'Tiến Vũ', 'Thái Bình', 175000, 1, 'Giao vào chủ nhật', '2020-12-15 22:53:11', 1),
(27, 'vutien97dhtb@gmail.com', '0943828536', 'Tiến Vũ', 'Thái Bình', 295000, 1, '', '2020-12-19 22:14:58', 0),
(28, 'vutien97dhtb@gmail.com', '0943828536', 'Tiến Vũ', 'Thái Bình', 620000, 2, 'Không có ghi chú', '2021-01-05 07:34:09', 1),
(29, 'vutien97dhtb@gmail.com', '0943828536', 'Tiến Vũ', 'Thái Bình', 500000, 2, 'Không', '2021-01-20 12:17:07', 1),
(30, 'vutien97dhtb@gmail.com', '', 'Tiến Vũ', 'Thái Bình', 460000, 4, '', '2021-01-21 04:57:25', 0);

-- --------------------------------------------------------

--
-- Table structure for table `billdetail`
--

DROP TABLE IF EXISTS `billdetail`;
CREATE TABLE `billdetail` (
  `id` bigint(20) NOT NULL,
  `id_product` bigint(20) NOT NULL,
  `id_bill` bigint(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `billdetail`
--

INSERT INTO `billdetail` (`id`, `id_product`, `id_bill`, `quantity`, `total`) VALUES
(3, 1, 3, 1, 20000),
(4, 22, 3, 1, 200000),
(5, 7, 3, 1, 200000),
(6, 1, 4, 1, 20000),
(7, 21, 4, 1, 200000),
(8, 11, 5, 3, 600000),
(9, 15, 5, 2, 400000),
(10, 1, 6, 1, 20000),
(12, 1, 7, 1, 20000),
(13, 21, 7, 2, 400000),
(14, 7, 7, 1, 200000),
(15, 17, 8, 1, 200000),
(16, 1, 8, 1, 20000),
(17, 19, 8, 1, 200000),
(18, 1, 9, 1, 20000),
(19, 19, 9, 1, 200000),
(20, 7, 9, 1, 200000),
(21, 1, 10, 1, 20000),
(22, 1, 11, 1, 20000),
(23, 7, 11, 1, 200000),
(24, 1, 12, 1, 20000),
(26, 1, 13, 1, 20000),
(27, 7, 14, 1, 200000),
(28, 13, 14, 1, 200000),
(29, 1, 15, 3, 60000),
(30, 25, 15, 2, 400000),
(31, 1, 16, 1, 20000),
(32, 11, 16, 1, 200000),
(33, 1, 17, 3, 60000),
(34, 23, 17, 2, 400000),
(35, 18, 18, 1, 200000),
(36, 19, 18, 1, 200000),
(37, 22, 18, 1, 200000),
(38, 11, 18, 1, 200000),
(39, 33, 19, 1, 265000),
(40, 1, 19, 1, 175000),
(41, 30, 19, 1, 155000),
(42, 33, 21, 1, 265000),
(43, 1, 22, 1, 175000),
(44, 30, 22, 1, 155000),
(45, 30, 23, 1, 155000),
(46, 31, 23, 1, 325000),
(47, 1, 24, 1, 175000),
(48, 30, 25, 1, 155000),
(49, 1, 26, 1, 175000),
(50, 25, 27, 1, 295000),
(51, 4, 28, 1, 365000),
(52, 14, 28, 1, 255000),
(53, 1, 29, 1, 175000),
(54, 24, 29, 1, 325000),
(55, 13, 30, 4, 460000);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `description` text COLLATE utf8_vietnamese_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'Nhẫn', NULL),
(2, 'Lắc tay', NULL),
(3, 'Khuyên tai', NULL),
(4, 'Dây chuyền', NULL),
(5, 'Lắc chân', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `url`) VALUES
(1, 'Trang chủ', 'trang-chu'),
(4, 'Giỏ hàng', 'gio-hang'),
(5, 'Bài viết', NULL),
(6, 'Liên hệ', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(20) NOT NULL,
  `id_category` int(11) NOT NULL,
  `size` varchar(255) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `price` double NOT NULL,
  `sale` int(3) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `highlight` tinyint(1) NOT NULL,
  `new_product` tinyint(1) NOT NULL,
  `detail` longtext COLLATE utf8_vietnamese_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `quantity` int(11) NOT NULL,
  `img` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `id_category`, `size`, `name`, `price`, `sale`, `title`, `highlight`, `new_product`, `detail`, `created_at`, `updated_at`, `quantity`, `img`) VALUES
(1, 1, 'L,M,S', 'Nhẫn Nguyệt Quế', 175000, 0, 'Nhẫn Nguyệt Quế', 1, 1, 'Mô tả sản phẩm<br>\r\n- Sản phẩm được làm hoàn toàn từ bạc ta Made in VN <br>\r\n\r\n- Quý khách vui lòng chọn size theo ảnh hướng dẫn, đặt size kèm tên.<br>\r\nVdu: Nguyễn Thị A size 6 <br>\r\n\r\n- Được thiết kế tỉ mỉ từ những người thợ kim hoàn tận tâm với tay nghề cao<br>\r\n\r\n- Tặng kèm hộp handmade độc quyền và tag bảo hành đánh bóng bạc trọn đời từ 21Cm<br>', '2021-01-20 12:17:08', '2020-12-15 18:00:50', 42, 'nhan-nguyet-que.png'),
(3, 3, 'L,S,M', 'Khuyên Leo', 195000, 0, 'Khuyên Leo', 1, 0, 'Mô tả sản phẩm<br>\r\n- Sản phẩm được làm hoàn toàn từ bạc 925 cao cấp <br>\r\n\r\n- Sản phẩm có 2 màu đá: trắng và xanh. Khi đặt hàng quý khách đặt màu kèm theo tên <br>\r\nVdu: Nguyễn Thị A - Màu trắng <br>\r\n\r\n- Sản phẩm được thiết kế tỉ mỉ từ những người thợ kim hoàn tận tâm với tay nghề cao<br>\r\n\r\n- Tặng kèm hộp handmade độc quyền và tag bảo hành đánh bóng bạc trọn đời từ 21Cm<br>', '2020-12-14 22:09:48', '2020-12-14 22:09:48', 50, 'khuyen-leo.jpg'),
(4, 4, 'L,S,M', 'Dây chuyền bạc Diamond Flowers', 365000, 0, 'Dây chuyền bạc Diamond Flowers', 1, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 <br>\r\n\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>', '2021-01-05 07:34:09', '2020-12-19 21:24:21', 49, 'day-chuyen-bac-diamond-flowers.jpg'),
(6, 5, 'L,S,M', 'Lắc chân bạc Lucky', 245000, 0, 'Lắc chân bạc Lucky', 0, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 <br>\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>\r\n- Giao hàng toàn quốc', '2020-12-19 21:24:33', '2020-12-19 21:24:33', 50, 'lac-chan-bac-lucky.jpg'),
(7, 1, 'L,S,M', 'Nhẫn bạc Hype', 185000, 0, 'Nhẫn bạc Hype', 1, 1, 'Mô tả sản phẩm<br>\r\n- 21 Centimeters - Tiệm Bạc của những cô gái mộng mer<br>\r\n- Chất liệu: Bạc ta <br>\r\n- Nhẫn hở, có thể điều chỉnh độ rộng <br>\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)', '2020-12-19 21:13:38', '2020-12-19 21:13:38', 47, 'nhan-bac-hype.jpg'),
(11, 2, 'L,S,M', 'Lắc tay bạc Curtis', 385000, 0, 'Lắc tay bạc Curtis', 1, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 <br>\r\n\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>', '2020-12-19 21:24:44', '2020-12-19 21:24:44', 45, 'lac-tay-bac-curtis.jpg'),
(13, 3, 'L,S,M', 'Khuyên tai bạc Blink', 115000, 0, 'Khuyên tai bạc Blink', 1, 0, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 <br>\r\n\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>', '2020-12-19 21:25:04', '2020-12-19 21:25:04', 49, 'khuyen-tai-bac-blink.jpg'),
(14, 4, 'L,S,M', 'Dây chuyền Simple Diamond', 255000, 0, 'Dây chuyền Simple Diamond', 0, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 <br>\r\n\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)', '2021-01-05 07:34:09', '2020-12-19 21:23:54', 49, 'day-chuyen-simple-diamond.jpg'),
(15, 5, 'L,S,M', 'Lắc chân LC34', 215000, 0, 'Lắc chân LC34', 1, 1, 'Mô tả sản phẩm <br>\r\n- Sản phẩm được làm hoàn toàn từ bạc 925 cao cấp <br>\r\n\r\n- Được thiết kế tỉ mỉ từ những người thợ kim hoàn tận tâm với tay nghề cao <br>\r\n\r\n- Tặng kèm hộp handmade độc quyền và tag bảo hành đánh bóng bạc trọn đời từ 21Cm', '2020-12-19 21:31:05', '2020-12-19 21:31:05', 48, 'lac-chan-lc34.jpg'),
(16, 1, 'L,S,M', 'Nhẫn bạc Lynk', 165000, 0, 'Nhẫn bạc Lynk', 0, 0, 'Mô tả sản phẩm <br>\r\n- Chất liệu: Bạc ta <br>\r\n- Nhẫn hở, có thể điều chỉnh độ rộng <br>\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)', '2020-12-19 21:34:20', '2020-12-19 21:34:20', 50, 'nhan-bac-lynk.jpg'),
(17, 2, 'L,S,M', 'Lắc tay bạc Butterfly', 235000, 0, 'Lắc tay bạc Butterfly', 1, 0, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 <br>\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>\r\n- Giao hàng toàn quốc', '2020-12-19 21:39:19', '2020-12-19 21:39:19', 49, 'lac-tay-bac-butterfly.png'),
(18, 3, 'L,S,M', 'Khuyên tai Curve', 175000, 0, 'Khuyên tai Curve', 0, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 <br>\r\n\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)', '2020-12-19 21:41:55', '2020-12-19 21:41:55', 49, 'khuyen-tai-bac-curve.jpg'),
(19, 4, 'L,S,M', 'Dây chuyền bạc Cici', 335000, 0, 'Dây chuyền bạc Cici', 1, 1, 'Mô tả sản phẩm\r\n- Chất liệu: Bạc 925 <br>\r\n\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)', '2020-12-19 21:44:18', '2020-12-19 21:44:18', 48, 'day-chuyen-bac-cici.jpg'),
(20, 5, 'L,S,M', 'Lắc chân Mỏ neo', 245000, 0, 'Lắc chân Mỏ neo', 0, 0, 'Mô tả sản phẩm<br>\r\n- Sản phẩm được làm hoàn toàn từ bạc 925 cao cấp <br>\r\n\r\n- Được thiết kế tỉ mỉ từ những người thợ kim hoàn tận tâm với tay nghề cao<br>\r\n\r\n- Tặng kèm hộp handmade độc quyền và tag bảo hành đánh bóng bạc trọn đời từ 21Cm<br>', '2020-12-19 22:13:37', '2020-12-19 22:13:37', 50, 'lac-chan-mo-neo.jpg'),
(21, 1, 'L,S,M', 'Nhẫn Minn', 155000, 0, 'Nhẫn Minn', 1, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925<br>\r\n- Nhẫn thiết kế hở, có thể tự điều chỉnh size bằng cách bóp nhẹ hoặc kéo mở <br>\r\n- Tặng kèm hộp giấy handmade, thân thiện với môi trường <br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Giao hàng toàn quốc<br>\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sự dụng: Sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.', '2020-12-19 21:48:27', '2020-12-19 21:48:27', 48, 'nhan-minn.png'),
(22, 2, 'L,S,M', 'Lắc tay kép Lucky', 345000, 0, 'Lắc tay kép Lucky', 1, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 \r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>\r\n- Giao hàng toàn quốc', '2020-12-19 21:50:44', '2020-12-19 21:50:44', 47, 'lac-tay-kep-lucky.png'),
(23, 3, 'L,S,M', 'Khuyên tai bạc Apus', 125000, 0, 'Khuyên tai bạc Apus', 1, 1, 'Mô tả sản phẩm <br>\r\n- Chất liệu: Bạc 925 <br>\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)', '2020-12-19 21:52:48', '2020-12-19 21:52:48', 48, 'khuyen-tai-bac-apus.jpg'),
(24, 4, 'L,S,M', 'Dây chuyền bạc Angel Wings', 325000, 0, 'Dây chuyền bạc Angel Wings', 1, 0, 'Mô tả sản phẩm <br>\r\n- Chất liệu: Bạc 925 <br>\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)', '2021-01-20 12:17:08', '2020-12-19 21:54:48', 49, 'day-chuyen-bac-angel-wings.jpg'),
(25, 5, 'L,S,M', 'Lắc chân Cylinder', 295000, 0, 'Lắc chân Cylinder', 1, 1, 'Mô tả sản phẩm<br>\r\n- Sản phẩm được làm hoàn toàn từ bạc 925 cao cấp <br>\r\n\r\n- Được thiết kế tỉ mỉ từ những người thợ kim hoàn tận tâm với tay nghề cao<br>\r\n\r\n- Tặng kèm hộp handmade độc quyền và tag bảo hành đánh bóng bạc trọn đời', '2020-12-19 21:57:17', '2020-12-19 21:57:17', 48, 'lac-chan-cylinder.jpg'),
(26, 2, 'L,S,M', 'Lắc tay kép Bally', 235000, 0, 'Lắc tay kép Bally', 1, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925<br>\r\n- Tặng kèm: hộp giấy handmade thân thiện với môi trường<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>\r\n- Bảo hành: Đánh sáng miễn phí trọn đời<br>\r\n- Giao hàng toàn quốc<br>\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.', '2020-12-19 21:59:37', '2020-12-19 21:59:37', 50, 'lac-tay-kep-bally.jpg'),
(27, 3, 'L,S,M', 'Khuyên tai bạc Cỏ ba lá', 115000, 0, 'Khuyên tai bạc Cỏ ba lá', 1, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 <br>\r\n\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)', '2020-12-19 22:01:24', '2020-12-19 22:01:24', 50, 'khuyen-tai-bac-cobala.png'),
(28, 4, 'L,S,M', 'Dây chuyền bạc Butterfly', 285000, 0, 'Dây chuyền bạc Butterfly', 1, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 <br>\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>\r\n- Giao hàng toàn quốc', '2020-12-19 22:03:32', '2020-12-19 22:03:32', 50, 'day-chuyen-bac-butterfly.png'),
(29, 1, NULL, 'Nhẫn Jizz', 135000, NULL, 'Nhẫn Jizz', 0, 1, 'Mô tả sản phẩm <br>\r\n-Sản phẩm được làm hoàn toàn từ bạc ta 925 cao cấp<br>\r\n\r\n-Nhẫn với thiết kế vòng tròn không khép kín, có thể tự điều chỉnh để vừa hầu hết mọi cỡ ngón tay.<br>\r\n\r\n-Được thiết kế tỉ mỉ từ những người thợ kim hoàn tận tâm với tay nghề cao<br>\r\n\r\n-Tặng kèm hộp handmade độc quyền và tag bảo hành đánh bóng bạc trọn đời từ 21Cm<br>', '2020-12-13 00:49:55', '2020-12-13 00:32:25', 50, 'nhan-jizz.jpg'),
(30, 3, NULL, 'Khuyên Galaxy', 155000, NULL, 'Khuyên Galaxy', 0, 1, 'Mô tả sản phẩm <br>\r\n- Chất liệu: Bạc 925<br>\r\n- Tặng kèm hộp giấy handmade, thân thiện với môi trường <br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Giao hàng toàn quốc<br>\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sự dụng: Sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>', '2020-12-19 21:36:52', '2020-12-19 21:36:52', 45, 'khuyen-galaxy.jpg'),
(31, 2, NULL, 'Lắc tay Blue Sapphire', 325000, NULL, 'Lắc tay Blue Sapphire', 0, 1, 'Mô tả sản phẩm <br>\r\n- Sản phẩm được làm hoàn toàn từ bạc 925 cao cấp, đá nhân tạo. <br>\r\n\r\n- Lắc có đoạn dây phụ 2cm để điều chỉnh độ rộng linh hoạt <br>\r\n\r\n- Được thiết kế tỉ mỉ từ những người thợ kim hoàn tận tâm với tay nghề cao<br>\r\n\r\n- Tặng kèm hộp handmade độc quyền và tag bảo hành đánh bóng bạc trọn đời từ 21Cm<br>', '2020-12-16 21:18:23', '2020-12-15 17:59:32', 48, 'lac-tay-blue-sapphire.jpg'),
(33, 5, NULL, 'Lắc chân Nguyệt quế', 265000, NULL, 'Lắc chân Nguyệt quế', 0, 1, 'Mô tả sản phẩm<br>\r\n- Sản phẩm được làm hoàn toàn từ bạc 925 cao cấp <br>\r\n\r\n- Được thiết kế tỉ mỉ từ những người thợ kim hoàn tận tâm với tay nghề cao<br>\r\n\r\n- Tặng kèm hộp handmade độc quyền và tag bảo hành đánh bóng bạc trọn đời từ 21Cm<br>', '2020-12-15 17:37:01', '2020-12-15 17:37:01', 48, 'lac-chan-nguyet-que.png'),
(34, 4, NULL, 'Dây chuyền Snow', 255000, NULL, 'Dây chuyền Snow', 0, 1, 'Mô tả sản phẩm<br>\r\n- Sản phẩm được làm hoàn toàn từ bạc 925 cao cấp <br>\r\n\r\n- Được thiết kế tỉ mỉ từ những người thợ kim hoàn tận tâm với tay nghề cao<br>\r\n\r\n- Tặng kèm hộp handmade độc quyền và tag bảo hành đánh bóng bạc trọn đời từ 21Cm<br>', '2020-12-15 22:56:52', '2020-12-15 22:56:52', 50, 'day-chuyen-snow.png'),
(35, 4, NULL, 'Dây chuyền bạc Double Diamond', 385000, NULL, 'Dây chuyền bạc Double Diamond', 0, 1, 'Mô tả sản phẩm<br>\r\n- Chất liệu: Bạc 925 <br>\r\n\r\n- Hướng dẫn bảo quản: Cất vào túi nilon kín khi không dùng đến, tránh tiếp xúc hóa chất, chất tẩy rửa mạnh, có thể làm sáng bằng kem đánh răng.<br>\r\n- Lưu ý khi sử dụng: Do đặc tính của bạc là kim loại mềm, dễ đứt gãy nên khách hàng chú ý sử dụng nhẹ nhàng, tránh vướng mắc vào quần áo.<br>\r\n- Tặng kèm hộp đựng handmade độc quyền <br>\r\n- Bảo hành đánh sáng trọn đời<br>\r\n- Sản phẩm được đảm bảo về chất lượng, có hỗ trợ kiểm định theo nhu cầu khách hàng (phí 20k)<br>', '2020-12-19 21:35:19', '2020-12-19 21:35:19', 50, 'day-chuyen-bac-double-diamond.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `slides`
--

DROP TABLE IF EXISTS `slides`;
CREATE TABLE `slides` (
  `id` int(11) NOT NULL,
  `img` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `caption` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `content` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `slides`
--

INSERT INTO `slides` (`id`, `img`, `caption`, `content`) VALUES
(1, '1.jpg', '', ''),
(2, '2.jpg', '', ''),
(3, '3.jpg', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(11) NOT NULL,
  `role` tinyint(1) NOT NULL,
  `email` varchar(100) COLLATE utf8_vietnamese_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_vietnamese_ci NOT NULL,
  `display_name` varchar(100) COLLATE utf8_vietnamese_ci NOT NULL,
  `address` text COLLATE utf8_vietnamese_ci,
  `phone` varchar(10) COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `role`, `email`, `password`, `display_name`, `address`, `phone`, `created_at`, `status`) VALUES
(1, 0, 'a@gmail.com', '123456', 'Vũ Xuân Tiến', 'Thái Bình', '0943828536', '2020-12-14 23:29:27', 0),
(2, 1, 'vutien97dhtb@gmail.com', '$2a$08$t5drlimZvKjycXZH7io1zu55I0ao5wwR8WWPpZgCMA23YyhvFnQ.m', 'Tiến Vũ', 'Thái Bình', '0943828536', '2020-12-15 17:08:34', 1),
(4, 1, 'vxt.97dhtb01@gmail.com', '$2a$08$fvKrGORYCL6mLXAiL5K1BOKW4XJuB1ZuP0MqJLcGNNl0nb7PAD8Cy', 'Vũ Tiến', '', '', '2020-12-15 17:06:31', 1),
(5, 0, 'b@gmail.com', '$2a$08$SkVjzmrv3MUeWRvAUzIcIuEzv4srzXMp7HSwSogiUuM1GfQU9w7ve', 'Vũ Xuân Tiến', 'Hà Nội', '0943828536', '2020-12-19 09:35:06', 1),
(6, 0, 'c@gmail.com', '$2a$08$ScKxYMWD.ylds9ZEIbJkN.pbTv2BvDio3aWESZ3QnzKa50QPRaJ7q', 'Tiến', 'Hà Nội', '0943828536', '2020-12-19 10:10:28', 1),
(7, 0, 'd@gmail.com', '$2a$08$hMQyvwpbDnWM.6A.zxMKYOfD5ZcMp3wKnN665ohneE9iia1QiWRTu', 'Tiáº¿n VÅ© ', 'ThÃ¡i BÃ¬nh', '0943828536', '2020-12-13 16:46:42', 1),
(8, 0, 'e@gmail.com', '$2a$08$VuZBSKVrveADLubs0crGqOJsr3KB9b7ZNMHYs7l6uHTTIi.kBK5tC', 'Vũ Xuân Tiến', 'Thái Bình', '0943828536', '2020-12-13 16:46:42', 1),
(9, 0, 'f@gmail.com', '$2a$08$W0fjvPoN78/CTzIeeVJs9eVsy4QkcO2Lz26bswl4rPCTCgRcOPH2m', '', '', '', '2020-12-19 22:10:19', 0),
(10, 0, 'g@gmail.com', '$2a$08$2PPnDdv49lJ2W64M7i4zJu3GlkqP13jaexWRpdda2sg.9FG7WEX3.', 'Tiến', 'Bạch Mai, Hà Nội', '0943828536', '2020-12-13 16:50:08', 1),
(14, 0, 'vxt20156614@gmail.com', '$2a$08$nxItL.J5Sa.HA.b8mkfr5u8JXFLTtPAm.gcy0PE2LCyXC2UED4Raq', 'Tiến', '', '', '2020-12-19 09:08:28', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `billdetail`
--
ALTER TABLE `billdetail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_bill` (`id_bill`),
  ADD KEY `id_product` (`id_product`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_category` (`id_category`);

--
-- Indexes for table `slides`
--
ALTER TABLE `slides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `billdetail`
--
ALTER TABLE `billdetail`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `slides`
--
ALTER TABLE `slides`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `bill_ibfk_1` FOREIGN KEY (`email`) REFERENCES `user` (`email`);

--
-- Constraints for table `billdetail`
--
ALTER TABLE `billdetail`
  ADD CONSTRAINT `billdetail_ibfk_1` FOREIGN KEY (`id_bill`) REFERENCES `bill` (`id`),
  ADD CONSTRAINT `billdetail_ibfk_2` FOREIGN KEY (`id_product`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
